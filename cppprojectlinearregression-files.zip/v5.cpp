#include<iostream>
#include<vector>
#include<fstream>
#include<sstream>
#include<string>

using namespace std;
bool inverse(double m[11][11],double I[11][11],int n){

    //copies matrix Xx into copy and constructs identity matrix
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
           
            I[i][j]=(i==j)?1:0;
        }
    }
     
    //constructing the augemenetd matrix
    double m_I[11][22];
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
         m_I[i][j]=m[i][j];
         m_I[i][j+n]=(i==j)?1:0;
        }
    }
        //jordan gauss inverse method
        for(int col=0;col<n;col++){
            int pivot=col;//stores the row no of largest element in a column
            //finding the largest no in a column
            for(int i=col+1;i<n;i++){
                if(fabs(m_I[i][col])>fabs(m_I[pivot][col])){
                pivot=i;
                }
            }
            if(fabs(m_I[pivot][col])<1e-9){
                return false;
            }
            //swap the row with largest num with row 1
            for(int i=0;i<2*n;i++){
                swap(m_I[col][i],m_I[pivot][i]);
            }
            //making pivot =1
            double p=m_I[col][col];
            for(int i=0;i<2*n;i++){
                m_I[col][i]/=p;
            }
            //main core->>making all other enteries of that col =0
            for(int r=0;r<n;r++){
                if(r==col){continue;}
                double f=m_I[r][col];
               for(int j=0;j<2*n;j++){
                m_I[r][j]-=f*m_I[col][j];
               }
            }
}

        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                I[i][j]=m_I[i][j+n];
            }
        }
        return true;
}

int main(){
    ifstream file("houses.csv");
    if(!file.is_open()){
        cout<<"error: could not open the csv file"<<endl;
        return 1;//program stopped beacuse of error returning 1 prevents the other code from complin
    }
    string line;
    int num=0;
    int fea=0;
    getline(file,line);
    //counting no of features
    for(int i=0;i<line.length();i++){
        if(line[i]==','){
           fea++;
        }
    }
    //counting no of training example
    while(getline(file,line)){
        num++;
    }
    file.close();

    double X[1000][10];//stores the training data
    double Y[1000];//stores the price or output

    ifstream datafile("houses.csv");
    getline(datafile,line);//skips the first line

    //storing the training data into a 2-d array
    for (int i = 0; i < num; i++) {
    getline(datafile,line);
    stringstream ss(line);

    for (int j = 0; j < fea; j++) {
        string value;
        getline(ss, value, ',');
        X[i][j] = stod(value);
    }

    string value;
    getline(ss, value, ',');
    Y[i] = stod(value);
    }

    datafile.close();


    // heres where the main thing starts


    double w[10]={0};
    double b=0;
    double alpha=.1;

    //normalization of the feature values
    double xmin[10];
    double xmax[10];
    for(int i=0;i<fea ;i++){
            xmin[i]=X[0][i];
            xmax[i]=X[0][i];
        for(int j=0;j<num;j++){
      
            if(X[j][i]>xmax[i]){
                xmax[i]=X[j][i];
            }

            if(X[j][i]<xmin[i]){
                xmin[i]=X[j][i];
            }
        }
    }
    for(int i=0;i<fea;i++){
        for(int j=0;j<num;j++){
            if(xmax[i]!=xmin[i]){
            X[j][i]=(X[j][i]-xmin[i])/(xmax[i]-xmin[i]);
            }
            else{
                X[j][i]=0;
            }
        }
    }



    //gradient decent logic
    for(int iteration=0;iteration<100000;iteration++){
      
        double dw[10]={0};
        double db=0;
        for(int i=0;i<num;i++){
             double  predict=b;
            for(int j=0;j<fea;j++){
                predict+=w[j]*X[i][j];
            }

            double error=predict-Y[i];

            db+=error;

            for(int j=0;j<fea;j++){
            dw[j]+=error*X[i][j];
            }
        }
        //calculate the avg of gradient over all examples
        for(int i=0;i<fea;i++){
         dw[i]=dw[i]/num;
        }
        db=db/num;
         for(int i=0;i<fea;i++){
            w[i]=w[i]-alpha*dw[i];
         }
         b=b-alpha*db;

    }

    
     

      //implementing normal eqn
       int n=fea+1;//no of column in X matrix
       //+1 because Xo is always 1 as its bias
       double Xtx[11][11]={};
       double Xty[11]={};
       

      // making a matrix with column-1 of all 1 and other entries same as X
        double Xx[1000][11];
        for(int i=0;i<num;i++){
            Xx[i][0]=1;
            for(int j=1;j<=fea;j++){
                Xx[i][j]=X[i][j-1];
            }
        }
        //constructing Xtx
        for(int a=0;a<n;a++){
            for(int c=0;c<n;c++ ){
                double sum=0;
                for(int z=0;z<num;z++){
                    sum+=Xx[z][a]*Xx[z][c];
                }
                Xtx[a][c]=sum;
            }
        }
      //constructing Xty
      for(int i=0;i<n;i++){
        for(int j=0;j<num;j++){
         Xty[i]+=Xx[j][i]*Y[j];
        }
      }
      double inverseXtx[11][11];
       double theta[11]={0};
      if(inverse(Xtx,inverseXtx,n)){
       
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                theta[i]+=(inverseXtx[i][j])*Xty[j];
            }
        }
      }
      else{
        cout<<"cant find inverse"<<endl;
      }
       
      //2. predicting
      ifstream test("testing.csv");
        if(!test.is_open()){
        cout<<"error: could not open the csv file"<<endl;
        return 1;//program stoped beacuse of an error prevents the other code from complin
    }
      string read;
     getline(test,read);
     double Xtest[1000][10];
     double ytest[1000];
     int ntest=0;
     while(getline(test,read)){
        stringstream bb(read);
        string value;
        for(int j=0;j<fea;j++){
            getline(bb,value,',');
            Xtest[ntest][j]=stod(value);
        }
        getline(bb,value,',');
        ytest[ntest]=stod(value);
        
        ntest++;
     }
     test.close();
     for (int i = 0; i < ntest; i++) {
    for (int j = 0; j < fea; j++) {
        if (xmax[j] != xmin[j]) {
            Xtest[i][j] =
                (Xtest[i][j] - xmin[j]) /
                (xmax[j] - xmin[j]);
        } else {
            Xtest[i][j] = 0;
        }
    }
}
    //predicting for gradient decent
    for (int i = 0; i < ntest; i++) {
    double pred = b;

    for (int j = 0; j < fea; j++){
        pred += w[j] * Xtest[i][j];
    }

    cout << "House " << i + 1
         << " predicted price(gradient decent): " << pred << endl;
}
//predicting for normal eqn
  for(int i=0;i<ntest;i++){
    double predict2=theta[0];
    for(int j=0;j<fea;j++){
        predict2+=Xtest[i][j]*theta[j+1];
    }
    cout<<"house"<<i+1<<"prected price(normal eqn)"<<predict2<<endl;
  }
  
  //checking how accurate are our results
  // Calculating testing R-squared

double meanYtest = 0;

for (int i = 0; i < ntest; i++) {
    meanYtest += ytest[i];
}

meanYtest = meanYtest / ntest;

double ssTotalTest = 0;
double ssResidualTest = 0;
double ssResidualTest2 = 0;

for (int i = 0; i < ntest; i++) {


    double pred = b;
    double predne=theta[0];

    for (int j = 0; j < fea; j++) {
        pred += w[j] * Xtest[i][j];
        predne+=theta[j+1]*Xtest[i][j];
    }

    ssTotalTest +=
        (ytest[i] - meanYtest) *
        (ytest[i] - meanYtest);

    ssResidualTest +=
        (ytest[i] - pred) *
        (ytest[i] - pred);
     ssResidualTest2+=(ytest[i] - predne) *
        (ytest[i] - predne);
    
    
}

if (ssTotalTest != 0) {
    double R2Test =
        1.0 - ssResidualTest / ssTotalTest;
      double R2Test1 =
        1.0 - ssResidualTest2 / ssTotalTest;

    cout << "Testing R-squared(ge): "
         << R2Test << endl;
    cout<<"testing R-squared(ne)"<<R2Test1<<endl;
}
else {
    cout << "Testing R-squared cannot be calculated"
         << endl;
}


        return 0;
}